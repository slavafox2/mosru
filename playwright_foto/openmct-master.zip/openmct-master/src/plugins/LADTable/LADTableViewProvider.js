/*****************************************************************************
 * Open MCT, Copyright (c) 2014-2022, United States Government
 * as represented by the Administrator of the National Aeronautics and Space
 * Administration. All rights reserved.
 *
 * Open MCT is licensed under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * http://www.apache.org/licenses/LICENSE-2.0.
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations
 * under the License.
 *
 * Open MCT includes source code licensed under additional open source
 * licenses. See the Open Source Licenses file (LICENSES.md) included with
 * this source code distribution or the Licensing information page available
 * at runtime from the About dialog for additional information.
 *****************************************************************************/

import LADTableView from './LADTableView';

export default class LADTableViewProvider {
    constructor(openmct) {
        this.openmct = openmct;
        this.name = 'LAD Table';
        this.key = 'LadTable';
        this.cssClass = 'icon-tabular-lad';
    }

    canView(domainObject) {
        const supportsComposition = this.openmct.composition.supportsComposition(domainObject);
        const providesTelemetry = this.openmct.telemetry.isTelemetryObject(domainObject);

        return domainObject.type === 'LadTable'
            || (providesTelemetry && supportsComposition);
    }

    canEdit(domainObject) {
        return domainObject.type === 'LadTable';
    }

    view(domainObject, objectPath) {
        return new LADTableView(this.openmct, domainObject, objectPath);
    }

    priority(domainObject) {
        return this.openmct.priority.HIGH;
    }
}
