# My Items plugin
Defines top-level folder named "My Items" to store user-created items. Enabled by default, this can be disabled in a 
read-only deployment with no user-editable objects.

## Installation
```js
openmct.install(openmct.plugins.MyItems());
```