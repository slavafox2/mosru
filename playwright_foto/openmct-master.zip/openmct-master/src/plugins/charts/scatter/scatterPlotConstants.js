export const SCATTER_PLOT_VIEW = 'scatter-plot.view';
export const SCATTER_PLOT_KEY = 'telemetry.plot.scatter-plot';
export const SCATTER_PLOT_INSPECTOR_KEY = 'telemetry.plot.scatter-plot.inspector';
export const TIME_STRIP_KEY = 'time-strip';
